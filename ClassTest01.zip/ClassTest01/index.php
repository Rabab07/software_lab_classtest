<?php
require "db.php";
include "_header.php";

$genre = $_GET['genre'] ?? '';
if ($genre) {
  $stmt = $pdo->prepare("SELECT * FROM books WHERE genres LIKE ?");
  $stmt->execute(["%$genre%"]);
} else {
  $stmt = $pdo->query("SELECT * FROM books ORDER BY id DESC");
}
$books = $stmt->fetchAll();
?>

<!-- Filter Form -->
<form method="get" class="mb-3">
  <div class="input-group">
    <input type="text" name="genre" class="form-control" placeholder="Filter by genre" value="<?= htmlspecialchars($genre) ?>">
    <button class="btn btn-outline-secondary">Filter</button>
    <a href="index.php" class="btn btn-outline-secondary">Reset</a>
  </div>
</form>

<a href="create.php" class="btn btn-primary mb-3">+ Add Book</a>

<div class="card p-3 shadow-sm">
  <table class="table table-striped">
    <thead>
      <tr>
        <th>ID</th>
        <th>Title</th>
        <th>Author</th>
        <th>Genres</th>
        <th>Available</th>
        <th>Actions</th>
      </tr>
    </thead>
    <tbody>
      <?php if (!$books): ?>
        <tr>
          <td colspan="6" class="text-center text-muted">No books found</td>
        </tr>
        <?php else: foreach ($books as $book): ?>
          <tr>
            <td><?= $book['id'] ?></td>
            <td><?= htmlspecialchars($book['title']) ?></td>
            <td><?= htmlspecialchars($book['author']) ?></td>
            <td><?= htmlspecialchars($book['genres']) ?></td>
            <td><?= $book['availability'] ? "✅" : "❌" ?></td>
            <td>
              <a href="edit.php?id=<?= $book['id'] ?>" class="btn btn-warning btn-sm">Edit</a>
              <a href="delete.php?id=<?= $book['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Delete this book?')">Delete</a>
            </td>
          </tr>
      <?php endforeach;
      endif; ?>
    </tbody>
  </table>
</div>

<?php include "_footer.php"; ?>