<?php
require "db.php";
include "_header.php";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
  $title = $_POST["title"];
  $author = $_POST["author"];
  $genres = $_POST["genres"];
  $availability = isset($_POST["availability"]) ? 1 : 0;

  $stmt = $pdo->prepare("INSERT INTO books (title, author, availability, genres) VALUES (?, ?, ?, ?)");
  $stmt->execute([$title, $author, $availability, $genres]);

  header("Location: index.php");
  exit;
}
?>

<div class="card p-4 shadow-sm">
  <h5>Add a New Book</h5>
  <form method="post">
    <div class="mb-3">
      <label>Title</label>
      <input type="text" name="title" class="form-control" required>
    </div>
    <div class="mb-3">
      <label>Author</label>
      <input type="text" name="author" class="form-control" required>
    </div>
    <div class="mb-3">
      <label>Genres</label>
      <input type="text" name="genres" class="form-control">
    </div>
    <div class="form-check mb-3">
      <input type="checkbox" name="availability" class="form-check-input" checked>
      <label class="form-check-label">Available</label>
    </div>
    <button class="btn btn-success">Save</button>
    <a href="index.php" class="btn btn-secondary">Cancel</a>
  </form>
</div>

<?php include "_footer.php"; ?>